import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Client{

	BufferedReader in;
    PrintWriter out;
    private JFrame mainFrame = new JFrame("Chat Room");
    private JLabel enterMessage;
    private JTextField textField;
    private JTextArea messageArea;
    private JPanel controlPanel;

    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://localhost/chatroom";
	static final String USER = "root";
	static final String PASS = "1234";
	
    
    public Client() {
    	prepareGUI();
    	
    }
    
    public void prepareGUI(){
    	// GUI
        mainFrame = new JFrame("Java Swing Examples");
        mainFrame.setSize(500,450);
        mainFrame.setLayout(new GridLayout(3, 1));
        
        mainFrame.addWindowListener(new WindowAdapter() {
           public void windowClosing(WindowEvent windowEvent){
              System.exit(0);
           }        
        });   
        
        controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout());
        
        mainFrame.add(controlPanel);
        mainFrame.setVisible(true);
    }
    
    public void showChatRoom(){
    	enterMessage = new JLabel("**Enter message and Press enter to send**");
    	textField = new JTextField(40);
    	messageArea = new JTextArea(9, 40);

    	// Add Listeners
        textField.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                out.println(textField.getText());
                textField.setText("");
            }
        });
        
        controlPanel.add(enterMessage);
        controlPanel.add(textField);
        controlPanel.add(messageArea);
        mainFrame.add(new JScrollPane(messageArea));
        mainFrame.setVisible(true);
    }

    
    private String getServerAddress() {
        return JOptionPane.showInputDialog(
        		mainFrame,
            "Enter IP Address of the Server: localhost",
            "Welcome To My Chat Room",
            JOptionPane.QUESTION_MESSAGE);
    }

    
    private String getName() {
        return JOptionPane.showInputDialog(
        		mainFrame,
            "Choose nick name:",
            "Screen name selection",
            JOptionPane.PLAIN_MESSAGE);
    }
    
    @SuppressWarnings("resource")
    private void run() throws IOException {
        String serverAddress = getServerAddress();
        Socket socket = new Socket(serverAddress, 9001);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new PrintWriter(socket.getOutputStream(), true);

        String name = getName();
        Connection conn = null;
		Statement stmt = null;
		
		//print out in chat box
        while (true) {
        	String line = in.readLine();
            if (line.startsWith("SUBMITNAME")) {
                out.println(name);
            } else if (line.startsWith("NAMEACCEPTED")) {
                textField.setEditable(true);
            } else if (line.startsWith("MESSAGE")) {
                messageArea.append(line.substring(8) + "\n");
            }
            
            try{
    			Class.forName("com.mysql.jdbc.Driver");
    			System.out.println("Connecting to a selected database...");
    			conn =  DriverManager.getConnection( DB_URL, USER, PASS);
    			System.out.println("Connected to database successfully...");
    			System.out.println("Inserting records into database");
    			stmt =  conn.createStatement();
    			
    			if(line == "SUBMITNAME"){
    				
    			}else if(line == "NAMEACCEPTED"){
    				
    			}else{
    				String message = line.substring(8);
    				String sql = "insert into chat " + 
   			             "values (" + "\'" + name + "\'," + " \'" + message + "\')";
   			        stmt.executeUpdate(sql);
    			}
    			
    		}catch(SQLException se){
    			se.printStackTrace();
    		}catch(Exception e){
    			e.printStackTrace();
    		}finally{
    			try{
    				if(stmt != null){
    					conn.close();
    				}
    			}catch(SQLException se){
    				
    			}
    			try{
    				if(conn != null){
    					conn.close();
    				}
    			}catch(SQLException se){
    				se.printStackTrace();
    			}
    		}
        }   
    }

    public static void main(String[] args) throws Exception {
        Client client = new Client();
        client.showChatRoom();
        client.run();
        
    }
}
